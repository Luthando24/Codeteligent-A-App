const toggle-button = document.getElementByClass('toggle-button')[0]
const navbar-links = document.getElementByClass('navbar-links')[0]

toggle-button.addEventListener('click', () => {
navbar-links.classList.toggle('active')
}
)